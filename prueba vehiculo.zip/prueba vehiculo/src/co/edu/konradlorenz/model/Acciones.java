
package co.edu.konradlorenz.model;


public interface Acciones {
    
    void encender();
    void acelerar();
    void frenar();
    void apagar();
}
